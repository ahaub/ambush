﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sighted : MonoBehaviour
{
    // Start is called before the first frame update
    void Awake()
    {
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public GameObject guardManager;
    void Start()
    {
        guardManager = GameObject.Find("GuardManager");
    }
    void OnTriggerEnter2D(Collider2D col) {

        if (GetComponent<SpriteRenderer>().sprite.name == "coneofvisionwide")
        {
            guardManager.GetComponent<GuardManager>().Detected(1);
            GetComponentInParent<UMovement>().Stop();
        }
        else
        {
            guardManager.GetComponent<GuardManager>().Detected(0);
            //GetComponentInParent<LMovement>().Stop();
        }

        /* if (col.gameObject.tag == "Player") {
            Debug.Log("Player sighted!!!");
        }*/
    }
    void OnTriggerExit2D(Collider2D col)
    {
        guardManager.GetComponent<GuardManager>().NotDetected();
        GetComponentInParent<UMovement>().Go();
    }



}
